-- Firma logo alanını ekle
ALTER TABLE firmalar ADD COLUMN firma_logo TEXT;
